package principioRU;



public class ClasePrincipal {
    
    public ClasePrincipal(){
    
        EntradaDatos run = new EntradaDatos();
        run.entradaDatos();
        
    }

    public static void main(String[] args) {
        
        ClasePrincipal correr = new ClasePrincipal();
        
    }
}
