package principioAC;

public class Run extends ClasePrincipal{
    
    public static void main(String[] args) {
        
        ClasePrincipal run = new ClasePrincipal();
    }

}
