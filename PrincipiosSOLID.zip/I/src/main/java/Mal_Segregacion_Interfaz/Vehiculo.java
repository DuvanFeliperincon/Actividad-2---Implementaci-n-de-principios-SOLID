
package Mal_Segregacion_Interfaz;

public interface Vehiculo {
    void setprecio (double precio);
    void setcolor  (String color);
    void iniciar();
    void frenar();
    void volar();
}
